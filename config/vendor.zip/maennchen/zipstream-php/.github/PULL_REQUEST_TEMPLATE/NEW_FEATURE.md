<!---
name: 🎉 New Feature
about: You have implemented some neat idea that you want to make part of ZipStream-PHP?
labels: type/enhancement
--->

<!--
- Please target the `main` branch of ZipStream-PHP.
-->
